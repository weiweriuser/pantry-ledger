export default {output:'export',basePath:'/pantry-ledger',trailingSlash:true,images:{unoptimized:true},poweredByHeader:false};
