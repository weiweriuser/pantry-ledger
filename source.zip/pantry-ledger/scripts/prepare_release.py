from pathlib import Path
from html.parser import HTMLParser
import base64,hashlib,shutil,zipfile,json
class Scripts(HTMLParser):
 def __init__(self): super().__init__(convert_charrefs=False);self.active=False;self.parts=[];self.scripts=[]
 def handle_starttag(self,t,a):
  if t=='script':self.active='src' not in dict(a);self.parts=[]
 def handle_data(self,d):
  if self.active:self.parts.append(d)
 def handle_endtag(self,t):
  if t=='script' and self.active:self.scripts.append(''.join(self.parts));self.active=False
root=Path(__file__).resolve().parent.parent
release=root/'release'
shutil.copytree(root/'out',release,dirs_exist_ok=True)
for f in release.rglob('*.html'):
 html=f.read_text();parser=Scripts();parser.feed(html)
 hashes=['\'sha256-'+base64.b64encode(hashlib.sha256(s.encode()).digest()).decode()+'\'' for s in parser.scripts]
 policy="default-src 'none'; script-src 'self' "+' '.join(hashes)+"; style-src 'self' 'unsafe-inline'; connect-src 'self' https://zmcwbews.api.sanity.io; img-src 'self' data:; font-src 'self'; base-uri 'none'; form-action 'none'; object-src 'none'"
 html=html.replace('<head>','<head><meta http-equiv="Content-Security-Policy" content="'+policy+'"/>',1)
 f.write_text(html)
(release/'.nojekyll').write_text('')
for file in ['README.md','SECURITY.md']:
 shutil.copy2(root/file,release/file)
with zipfile.ZipFile(release/'source.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for name in ['package.json','package-lock.json','next.config.mjs','.gitignore','README.md','SECURITY.md','app','lib','data','test','scripts']:
  p=root/name
  for f in (p.rglob('*') if p.is_dir() else [p]):
   if f.is_file():archive.write(f,'pantry-ledger/'+str(f.relative_to(root)))
for f in release.rglob('*'):
 if f.is_file() and f.suffix in ['.html','.js','.css','.md','.txt']:
  text=f.read_text()
  for private in ['start1990forme@gmail.com','CHI CUN WEI','Sentinel_','SANITY_AUTH_TOKEN','SANITY_WRITE_TOKEN','BEGIN PRIVATE KEY']:
   assert private not in text,(str(f),private)
print('Release prepared. Source allowlist excludes all old Astro/Studio files, vendor patches, credentials, caches and logs.')
print('Files:',sum(f.is_file() for f in release.rglob('*')))
