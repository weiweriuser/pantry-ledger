import './globals.css';
export const metadata={title:'Pantry Ledger · 食材更正記錄',description:'A fictional pantry evidence ledger. Compare corrections without inventing quantities.',referrer:'no-referrer'};
export default function Layout({children}) {return <html lang="zh-Hant"><body>{children}</body></html>;}
