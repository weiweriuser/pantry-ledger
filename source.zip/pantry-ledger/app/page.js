'use client';
import {useRef,useState} from 'react';
import demoDocuments from '../data/demo.json';
import {readDocuments} from '../lib/documents.mjs';
import {assessMeal} from '../lib/pantry.mjs';

export default function Page(){
 const [baseline,setBaseline]=useState(()=>readDocuments(demoDocuments));
 const [mode,setMode]=useState('after'),[source,setSource]=useState('demo'),[loading,setLoading]=useState(false);
 const [status,setStatus]=useState('虛構示範資料 / Local fictional demo');
 const [detail,setDetail]=useState('目前顯示本機虛構示範資料，尚未代表 Sanity 線上資料。');
 const generation=useRef(0);
 const rows=mode==='before'?baseline.observations.filter(o=>!o.supersedes):baseline.observations;
 function loadDemo(){generation.current++;setBaseline(readDocuments(demoDocuments));setSource('demo');setMode('after');setLoading(false);setStatus('虛構示範資料 / Local fictional demo');setDetail('目前顯示本機虛構示範資料，尚未代表 Sanity 線上資料。');}
 async function loadLive(){
  const request=++generation.current;setLoading(true);setStatus('正在讀取 Sanity…');
  try{
   const url=new URL('https://zmcwbews.api.sanity.io/v2026-10-03/data/query/production');
   url.searchParams.set('query','*[_type in ["ingredient", "observation", "meal"] && synthetic == true][0...200]');url.searchParams.set('perspective','published');
   const response=await fetch(url,{credentials:'omit',signal:AbortSignal.timeout(10000)});
   if(!response.ok)throw new Error('Request failed');
   const next=readDocuments((await response.json()).result);
   if(request!==generation.current)return;
   setBaseline(next);setSource('live');setMode('after');setStatus('Sanity 線上快照 / Live snapshot');setDetail(`讀取時間：${new Date().toLocaleString()}。下方操作不會寫入資料庫。`);
  }catch{
   if(request!==generation.current)return;
   setStatus('線上讀取失敗或資料尚未就緒');setDetail(source==='demo'?'下方仍是虛構示範資料，不是線上結果。':'下方保留上次成功讀取的舊快照，不代表最新資料。');
  }finally{if(request===generation.current)setLoading(false);}
 }
 return <><header><a href="#main" className="brand">PANTRY / LEDGER</a><span className="eyebrow">EVIDENCE BEFORE DINNER</span></header><main id="main">
  <section className="hero"><p className="eyebrow">食材更正記錄</p><h1>六顆蛋，還是<span>兩顆？</span></h1><p className="intro">保留來源、呈現未知，比較一則更正如何改變今晚能做的菜。</p><p className="english">Compare corrections. Keep the evidence. Don’t invent missing quantities.</p></section>
  <section className="toolbar" aria-label="資料來源"><div><strong role="status" aria-live="polite">{status}</strong><p>{detail}</p></div><div className="actions"><button onClick={loadLive} disabled={loading}>讀取 Sanity / Load live</button><button onClick={loadDemo} className="secondary">虛構示範 / Demo</button></div></section>
  <section className="experiment"><div><h2>比較更正前後</h2><p>僅在此分頁模擬，不會寫入資料庫。</p></div><div className="actions"><button className="secondary" aria-pressed={mode==='before'} onClick={()=>setMode('before')}>原始紀錄 / Before</button><button aria-pressed={mode==='after'} onClick={()=>setMode('after')}>套用更正 / After</button><button className="secondary" onClick={()=>setMode('after')}>重設 / Reset</button></div></section>
  <p id="scenario-status" aria-live="polite">{mode==='before'?'目前：僅原始紀錄 / Before corrections':'目前：包含已記錄的更正 / After corrections'}</p>
  <section aria-labelledby="meals-title"><div className="section-title"><h2 id="meals-title">今晚的可行性 <span>Meal feasibility</span></h2></div><div className="cards">
   {baseline.meals.map(meal=>{const result=assessMeal(rows,meal.requirements);return <article key={meal._id} className={'card '+result.state}><p className="badge">{result.state==='ready'?'份量足夠 / Ready':result.state==='short'?'食材不足 / Short':'需要確認 / Review'}</p><h3>{meal.labelZh}</h3><p className="muted">{meal.labelEn}</p>{result.items.map((item,index)=>{const name=baseline.ingredients.find(i=>i._id===item.required.ingredient)?.labelZh??item.required.ingredient;return <div key={index}><p>{name} · 需要 {item.required.quantity} {item.required.unit} · {item.state==='ready'?'足夠':item.state==='short'?`缺 ${Number(item.missing.toFixed(4))} ${item.required.unit}`:'數量或單位未確認'}</p><small>來源：{item.inventory.sources.map(s=>s.id).join(' → ')||'無紀錄'}</small></div>;})}</article>;})}
  </div></section>
  <section className="ledger" aria-labelledby="ledger-title"><div className="section-title"><h2 id="ledger-title">每筆紀錄都留下 <span>The evidence trail</span></h2></div>{baseline.observations.map(o=><article key={o.id} className={'record '+(o.supersedes?'correction':'')}><span className="badge">{o.supersedes?'更正 / CORRECTION':'紀錄 / OBSERVATION'}</span><h3>{o.originalText??o.id}</h3><p className="muted">{o.sourceLabel??'Demo'} · {o.id}</p>{o.supersedes&&<p>取代 / Supersedes: {o.supersedes}</p>}</article>)}</section>
  <aside><h3>這個工具刻意不猜測。</h3><p>公克不能直接換成顆數。半盒不等於固定重量。想買，不代表已經有。未知資料會要求確認。</p><p>Grams are not counts. Unknown package sizes stay unknown. A shopping wish is not inventory.</p></aside>
  <footer><p>所有庫存與份量均為虛構，僅供軟體展示，不是食譜、營養或食品安全建議。</p><p>Sanity project: zmcwbews · Public dataset: production · No analytics or account required for this viewer.</p><p>按下 Live 時會向 Sanity 傳送一般連線資訊（例如 IP）。此頁沒有寫入金鑰，也不會保存你輸入的私人資料。</p></footer>
 </main></>;
}
